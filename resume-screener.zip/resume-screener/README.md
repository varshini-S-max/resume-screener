# 📄 AI Resume Screener

A simple NLP tool that compares a resume (PDF) with a job description and shows:

- **Match score (%)**: semantic similarity using sentence embeddings
- **Matched skills**: skills required by the job that the resume has
- **Missing skills**: the skill gap to work on next

## How it works

1. Extract text from the resume PDF (`pdfplumber`)
2. Clean the text (lowercase, remove symbols)
3. Convert text to embeddings with `all-MiniLM-L6-v2` (`sentence-transformers`)
4. Split the resume into chunks, compare each chunk with the job description using **cosine similarity**, and average the top 3
5. Find matched / missing skills against `skills.txt`: case-insensitive, whole-word matching, and **aliases** (e.g. `ML` = `machine learning`, `JS` = `javascript`, `sklearn` = `scikit-learn`)

## Tech stack

Python · Streamlit · sentence-transformers · pdfplumber · pytest

## Run locally

```bash
git clone https://github.com/varshini-S-max/resume-screener.git
cd resume-screener
python -m venv venv
venv\Scripts\activate        # Windows  (Mac/Linux: source venv/bin/activate)
pip install -r requirements.txt
streamlit run app.py
```

## Run tests

```bash
pytest
```

## Project structure

```
resume-screener/
├── app.py              # Streamlit UI
├── screener.py         # Core logic
├── skills.txt          # Skills + aliases (edit to add more)
├── tests/              # Unit tests
├── requirements.txt
└── README.md
```

## Screenshots

> Add a screenshot of the app here: `![Demo](screenshots/demo.png)`

## Limitations

- Skills are found by keyword + alias match. Only aliases listed in `skills.txt` are understood (you can add your own: `skill name: alias1, alias2`).
- Scanned (image) PDFs are not supported (no OCR).
- The match score is a rough indicator, not a hiring decision.

## Future improvements

- Skill extraction with spaCy NER
- Rank multiple resumes for one job
- LLM-based resume improvement suggestions
- OCR support for scanned PDFs

## Author

<Your Name> · [LinkedIn](https://linkedin.com/in/your-profile)
